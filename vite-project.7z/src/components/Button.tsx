export default function Button(){
    return(
        <>
        <div className="bg-blue-600 rounded-[4px] ">
            <p className="text-white px-6 py-2 text-[14px] font-medium ">
                Ok
            </p>

        </div>
        </>
    )
}